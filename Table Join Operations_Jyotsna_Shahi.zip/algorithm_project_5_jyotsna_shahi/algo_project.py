# Author: Jyotsna Shahi
# Tx ID: A04993202
# Version: 1.0
# Description: Implementation of project 5, which was to implement different techniques
# to join two tables of size m and n with values between 0 to k-1 and find the common values


from timeit import default_timer as timer
import random

# Implement Linear Search Function
def linear_search(arr, element):
    # Iterate over the length of the array
    for i in range (len(arr)): 
        if arr[i] == element:
            return True
    return False

# Implement Merge Sort Function
def merge_sort(arr): #  Avg. run time O(nlogn)
	if len(arr) > 1:
		mid = len(arr) // 2
		left = arr[:mid]
		right = arr[mid:]

		# Recursive call on each half
		merge_sort(left)
		merge_sort(right)

		# Two iterators for traversing the two halves
		i = 0
		j = 0

		# Iterator for the main list
		k = 0

		while i < len(left) and j < len(right):
			if left[i] < right[j]:
				# The value from the left half has been used
				arr[k] = left[i]
				# Move the iterator forward
				i += 1
			else:
				arr[k] = right[j]
				j += 1

			# Move to the next slot
			k += 1

		# For all the remaining values
		while i < len(left):
			arr[k] = left[i]
			i += 1
			k += 1

		while j < len(right):
			arr[k]=right[j]
			j += 1
			k += 1

	return arr

# Implement Binary Search Function
def binary_search(array, target):
    lower = 0
    upper = len(array)
    while lower < upper:
    	#Getting the middle value of the array
        x = lower + (upper - lower) // 2 
        val = array[x]
        # If the target values is the middle itself return True
        if target == val:
            return True
        # if target value is larger than middle swap lower with middle value
        elif target > val:
            if lower == x: break        
            lower = x
        # if target value is lower than middle swap upper with middle value
        elif target < val:
            upper = x

    return False

### Main Program Begins

# Implementing Technique 1
def merge_intersection(arr1,arr2):

	i = j = count = 0
	sorted_array1 = sorted_array2 = result = []
	sorted_array1 = merge_sort(arr1)
	sorted_array2 = merge_sort(arr2)

	while i < len(sorted_array1) and j < len(sorted_array2):
		# If array1 [i] < array2[j] we know that the array1[i] does not exist in array2 
		# as i and j point to the smallest element in the respective arrays. 
		# So we move i forward.
		if sorted_array1[i] < sorted_array2[j]:
			i += 1
		elif sorted_array2[j] < sorted_array1[i]:
			j += 1
		
		# If array1[i] == array2[j] then we have found a common element and we advance 
		# both i and j by 1 and continue till the end of either of the array.
		else:
			result.append(sorted_array1[i])
			i += 1
			j += 1

	return result


# Implementing Technique 2
def sort_larger_table(arr1,arr2):
	# We first figure out which array is larger and which is smaller
	larger = smaller = sorted_array = result = []
	i = count = 0
	# Find the largest and smallest of the two array
	if (len(arr1) > len(arr2)):
		larger 	= arr1
		smaller = arr2
	else:
		larger 	= arr2
		smaller = arr1

	# Sort the largest array using merge sort
	sorted_array = merge_sort(larger)
	for i in smaller:
		# Search each value in the smaller array in larger array using binary search
		if (binary_search(sorted_array, i)):
			result.append(i)

	return result


# Implementing Technique 3
def sort_smaller_table(arr1,arr2):
	larger = smaller = sorted_array = result = []
	i = count = 0
	if (len(arr1)> len(arr2)):
		larger 	= arr1
		smaller = arr2
	else:
		larger 	= arr2
		smaller = arr1

	# Sort the smaller array using merge sort
	sorted_array = merge_sort(smaller)
	for i in larger:
		# Search each value in the larger array in smaller array using binary search
		if(binary_search(sorted_array, i)):
			result.append(i)

	return result 


# Implementing Technique 4
def search_larger_table(arr1, arr2):
	# We dont sort any of the arrays
	larger = smaller = result = []
	i = count = 0
	if (len(arr1)> len(arr2)):
		larger 	= arr1
		smaller = arr2
	else:
		larger 	= arr2
		smaller = arr1

	for i in smaller:
		if(linear_search(larger,i)):
			result.append(i)

	return result


# Create a new array to store the common values between the two tables
common_values = []

input_k = input("Enter the value k: ")
input_m = input("Enter the value m: ")
input_n = input("Enter the value n: ")

k = int(input_k)
m = int(input_m)
n = int(input_n)

# Creates two array with random unique values between 0..k-1
a = random.sample(range(0,k-1), m)
b = random.sample(range(0,k-1), n)


print("\n")
print("Executing the first join technique ...")
start = timer()
common_values = merge_intersection(a,b)
print ("Total Common values: ", common_values)
end = timer()
t1 = end-start
print("Time to execute the first join technique ...")
print(str(t1)+" seconds")

print("\n")
print("Executing the second join technique ...")
start = timer()
common_values = sort_larger_table(a,b)
print ("Total Common values: ", common_values)
end = timer()
t2 = end-start
print("Time to execute the second join technique ...")
print(str(t2)+" seconds")

print("\n")
print("Executing the third join technique ...")
start = timer()
common_values = sort_smaller_table(a,b)
print ("Total Common values: ", common_values)
end = timer()
t3 = end-start
print("Time to execute the third join technique ...")
print(str(t3)+" seconds")

print("\n")
print("Executing the fourth join technique ...")
start = timer()
common_values = search_larger_table(a,b)
print ("Total Common values: ", common_values)
end = timer()
t4 = end-start
print("Time to execute the fourth join technique ...")
print(str(t4)+" seconds")

# Find which technique was quickest in a particular scenario
print("\n")
if (min(t1,t2,t3,t4)==t1):
	print("First technique is the quickest")

elif (min(t1,t2,t3,t4)==t2):
	print("Second technique is the quickest")

elif (min(t1,t2,t3,t4)==t3):
	print("Third technique is the quickest")

else:
	print("Fourth technique is the quickest")

#end of program