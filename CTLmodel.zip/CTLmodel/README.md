# Project for CS 5392 @ Texas State University

See https://userweb.cs.txstate.edu/~rp31/projDescrMCheck_5392.html for directions.


