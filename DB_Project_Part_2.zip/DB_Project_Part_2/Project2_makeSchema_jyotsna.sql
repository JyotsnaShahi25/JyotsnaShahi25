-- Name - Jyotsna Shahi
-- Net_ID - j_s1294
--
--  Create a datbase for who does that application
--

set termout on
set feedback onn
prompt Building sample who does that application database.  Please wait ...
set termout off
set feedback off

create table Role (
	role_id NUMBER(5), 
	role VARCHAR2(25), 
	description VARCHAR2(200), 
	PRIMARY KEY (role_id));

insert into Role values (1, 'SUPER_USER', 'A SUPER_USER is an admin that manages all Users');
insert into Role values (2, 'END_USER', 'END_USER is a User that searches for a Business');
insert into Role values (3, 'BUSINESS_USER', 'BUSINESS_USER is a business that advertises its services on the application');


create table Super_user (
	super_user_id INT,
	email VARCHAR2(320),
	email_password VARCHAR2(25),
	first_name VARCHAR2(50),
	last_name VARCHAR2(50),
	phone_number VARCHAR2(14),
	role_id INT,
	creation_date DATE,
	last_updated_date DATE,
	last_updated_by INT,
	PRIMARY KEY (super_user_id),
	FOREIGN KEY (role_id) REFERENCES Role(role_id));

insert into Super_user values (001, 'jyotsna746@gmail.com', 'qwe746$$', 'Jyotsna', 'Shahi', '512-593-2222', 1, to_date('03-20-2021','MM-DD-YYYY'), to_date('03-31-2021','MM-DD-YYYY'), 001);
insert into Super_user values (002, 'sangeethaEswaran@gmail.com', 'asd@123', 'sangeetha', 'Eswaran', '912-343-5220', 1, to_date('03-20-2021','MM-DD-YYYY'), to_date('03-31-2021','MM-DD-YYYY'), 002);
insert into Super_user values (003, 'rancyThankachan@gmail.com', '!!987', 'Rancy', 'Thankachan', '712-593-1234', 1 , to_date('03-20-2021','MM-DD-YYYY'), to_date('03-31-2021','MM-DD-YYYY'), 003);
insert into Super_user values (004, 'emilly.ann@gmail.com', 'abcxx', 'Emily', 'Ann', '512-533-3435', 1, to_date('03-20-2021','MM-DD-YYYY'), to_date('03-31-2021','MM-DD-YYYY'),004);
insert into Super_user values (005, 'donna.ann@gmail.com', '123dfv', 'Donna', 'Ann', '979-666-0647', 1, to_date('03-20-2021','MM-DD-YYYY'), to_date('03-31-2021','MM-DD-YYYY'),005);

create table Users(
	user_id INT, 
	email VARCHAR2(320), 
	password VARCHAR2(25),
	approved_user NUMBER(1,0),
	first_name VARCHAR2(50),
	last_name VARCHAR2(50),
	phone_number VARCHAR2(14),
	role_id INT,
	creation_date DATE, 
	last_updated_date DATE, 
	last_updated_by INT, 
	PRIMARY KEY (user_id),
	FOREIGN KEY (role_id) REFERENCES Role(role_id));

insert into Users values (1231, 'joy23@gmail.com','sadface', '1', 'Joy', 'Gold', '786-687-0000', 2, to_date('03-25-2021','MM-DD-YYYY'), to_date('03-25-2021','MM-DD-YYYY'), 1231);
insert into Users values (1232, 'tom@gmail.com','S@tom12', '1', 'Tom', 'Doe', '566-687-0450', 2, to_date('03-25-2021','MM-DD-YYYY'), to_date('03-26-2021','MM-DD-YYYY'), 1232);
insert into Users values (1233, 'john.doe@gmail.com','@123john', '1', 'John', 'Doe', '786-687-0000', 2, to_date('03-26-2021','MM-DD-YYYY'), to_date('03-26-2021','MM-DD-YYYY'), 1233);
insert into Users values (1234, 'dave@mimundo.com','!!32jp', '1', 'Dave', 'Bautista', '512-593-3435', 3, to_date('03-27-2021','MM-DD-YYYY'), to_date('03-27-2021','MM-DD-YYYY'), 1234);
insert into Users values (1235, 'racheal.zane@ustaxfiler.com','happyface', '1', 'Racheal', 'Zane', '999-999-3435', 3, to_date('03-27-2021','MM-DD-YYYY'), to_date('03-28-2021','MM-DD-YYYY'), 1235);
insert into Users values (1236, 'lindsey.payne@blackrockbar.com','dudecoffee', '1', 'lindsey', 'Payne', '512-999-3435', 3, to_date('03-27-2021','MM-DD-YYYY'), to_date('03-28-2021','MM-DD-YYYY'), 1235);
insert into Users values (1237, 'li.fang@austinmotors.com','whereismycar', '1', 'Li', 'Fang', '123-345-6666', 3, to_date('03-27-2021','MM-DD-YYYY'), to_date('03-28-2021','MM-DD-YYYY'), 1235);
insert into Users values (1238, 'jay.cutler@dudewipes.com','babyface123', '1', 'Jay', 'Cutler', '222-333-3435', 3, to_date('03-27-2021','MM-DD-YYYY'), to_date('03-28-2021','MM-DD-YYYY'), 1235);
insert into Users values (1239, 'tina23@gmail.com','tina234', '1', 'Tina', 'Kapoor', '786-687-9876', 2, to_date('03-25-2021','MM-DD-YYYY'), to_date('03-25-2021','MM-DD-YYYY'), 1239);
insert into Users values (12310, 'june12@gmail.com','doglove', '1', 'June', 'Cheng', '786-687-2468', 2, to_date('03-25-2021','MM-DD-YYYY'), to_date('03-25-2021','MM-DD-YYYY'), 12310);

create table End_user (
	user_id INT,
	loyalty	NUMBER(5),
	referral_code VARCHAR2(50),
	favorites INT,
	preference VARCHAR2(20),
	FOREIGN KEY (user_id) REFERENCES Users(user_id));

insert into End_user values (1231, 500, 'ref_121', 2, 'Coffee');
insert into End_user values (1232, 500, 'ref_122', 2, 'Beer');
insert into End_user values (1233, 200, 'ref_123', 3, 'Wine');
insert into End_user values (1239, 700, 'ref_124', 3, 'Moped');
insert into End_user values (12310, 500, 'ref_125', 3, 'Cold Brew');

create table Business (
	business_id INT,
	business_name VARCHAR2(50),
	image VARCHAR2(100),
	website_url VARCHAR2(100),
	service_location VARCHAR2(100), 
	description VARCHAR2(500), 
	social_media VARCHAR2(100),
	week_day_from VARCHAR2(10), 
	week_day_to VARCHAR2(10), 
	hour_start VARCHAR2(6), 
	hour_close VARCHAR2(6), 
	PRIMARY KEY (business_id));

insert into Business values (2001, 'Mi Mundo Coffee', 'mimundo.jpg', 'www.mimundo.com','Round Rock, TX', 'Local coffee shop with sepciality lattes','instagram:@mimundoatx','Monday','Sunday','7:00','15:00');
insert into Business values (2002, 'US Tax Filer', 'taxfiler.jpg', 'www.ustaxfiler.org','Round Rock, TX', 'CPA that specialize in tax filing for immigrants','instagram:@ustaxfiler','Monday','Friday','9:00','17:00');
insert into Business values (2003, 'Black Rock Bar', 'blackrockbar.jpg', 'www.blackrockbar.com','Round Rock, TX', 'Local bar sepcializing in whiskey cocktail','instagram:@blackrockbaratx','Monday','Sunday','17:00','01:00');
insert into Business values (2004, 'Austin Motors', 'austinmotors.jpg', 'www.austinmotors.com','Cedar Park, TX', 'Car repair shop specializing in japanese brands','instagram:@austinmotors','Monday','Friday','9:00','19:00');
insert into Business values (2005, 'Dude Wipes', 'dudewipes.jpg', 'www.dudewipes.com','Austin, TX', 'Austin based company specializing in mens beauty products','instagram:@dudewipesatx','Monday','Sunday','9:00','15:00');


create table Business_user (
	user_id INT, 
	business_id INT, 
	FOREIGN KEY (user_id) REFERENCES Users(user_id),
	FOREIGN KEY (business_id) REFERENCES Business(business_id));

insert into Business_user values (1234, 2001);
insert into Business_user values (1235, 2002);
insert into Business_user values (1236, 2003);
insert into Business_user values (1237, 2004);
insert into Business_user values (1238, 2005);

create table Membership (
	membership_id INT,
	membership_name VARCHAR2(50),
	membership_type VARCHAR2(10),
	description VARCHAR2(500),
	cost_month DOUBLE PRECISION,
	cost_year DOUBLE PRECISION,
	creation_date DATE,
	start_date DATE,
	end_date DATE,
	PRIMARY KEY (membership_id));

insert into Membership values (101, 'B-MLB–Basic', 'Basic', 'Basic Membership for Businesses',9.99, 99.00,to_date('03-25-2021','MM-DD-YYYY'),to_date('03-26-2021','MM-DD-YYYY'),to_date('03-26-2022','MM-DD-YYYY'));
insert into Membership values (102, 'B-MLS–Standard', 'Standard', 'Standard Membership for Businesses',19.99, 199.00,to_date('03-25-2021','MM-DD-YYYY'),to_date('03-26-2021','MM-DD-YYYY'),to_date('03-26-2022','MM-DD-YYYY'));
insert into Membership values (103, 'B-MLP-Premium', 'Premium', 'Premium Membership for Businesses',34.99, 349.00,to_date('03-25-2021','MM-DD-YYYY'),to_date('03-26-2021','MM-DD-YYYY'),to_date('03-26-2022','MM-DD-YYYY'));
insert into Membership values (104, 'U-MLB–Basic', 'Basic', 'Basic Membership for User',0.00, 0.00,to_date('03-26-2021','MM-DD-YYYY'),to_date('03-26-2022','MM-DD-YYYY'),to_date('03-26-2022','MM-DD-YYYY'));
insert into Membership values (105, 'U-MLS–Standard', 'Standard', 'Standard Membership for User',4.99,59.88,to_date('03-25-2021','MM-DD-YYYY'),to_date('03-26-2021','MM-DD-YYYY'),to_date('03-26-2022','MM-DD-YYYY'));
insert into Membership values (106, 'U-MLS–Premium', 'Premium', 'Premium Membership for User',9.99, 119.88,to_date('03-25-2021','MM-DD-YYYY'),to_date('03-26-2021','MM-DD-YYYY'),to_date('03-26-2022','MM-DD-YYYY'));


create table Member (
	membership_id INT, 
	user_id INT, 
	start_date DATE,
	end_date DATE, 
	FOREIGN KEY (membership_id) REFERENCES Membership(membership_id),
	FOREIGN KEY (user_id) REFERENCES Users(user_id));

insert into Member values (104, 1231, to_date('03-26-2021','MM-DD-YYYY'), to_date('03-26-2022','MM-DD-YYYY'));
insert into Member values (105, 1232, to_date('03-26-2021','MM-DD-YYYY'), to_date('03-26-2022','MM-DD-YYYY'));
insert into Member values (106, 1233, to_date('03-26-2021','MM-DD-YYYY'), to_date('03-26-2022','MM-DD-YYYY'));
insert into Member values (106, 1234, to_date('03-26-2021','MM-DD-YYYY'), to_date('03-26-2022','MM-DD-YYYY'));
insert into Member values (101, 1235, to_date('03-26-2021','MM-DD-YYYY'), to_date('03-26-2022','MM-DD-YYYY'));
insert into Member values (102, 1236, to_date('03-26-2021','MM-DD-YYYY'), to_date('03-26-2022','MM-DD-YYYY'));


create table Feature (
	feature_id INT,
	feature_name VARCHAR2(50), 
	description VARCHAR2(500), 
	creation_date DATE, 
	start_date DATE, 
	end_date DATE, 
	PRIMARY KEY (feature_id));

insert into Feature values (1111, 'B-MLB–Basic-Feature','All the features available to a basic memebership to a business',to_date('03-25-2021','MM-DD-YYYY'),to_date('03-25-2021','MM-DD-YYYY'),to_date('03-26-2022','MM-DD-YYYY'));
insert into Feature values (1112, 'B-MLS–Standard-Feature','All the features available to a standard memebership to a business',to_date('03-25-2021','MM-DD-YYYY'),to_date('03-25-2021','MM-DD-YYYY'),to_date('03-26-2022','MM-DD-YYYY'));
insert into Feature values (1113, 'B-MLP–Premium-Feature','All the features available to a premium memebership to a business',to_date('03-25-2021','MM-DD-YYYY'),to_date('03-25-2021','MM-DD-YYYY'),to_date('03-26-2022','MM-DD-YYYY'));
insert into Feature values (1114, 'U-MLB–Basic-Feature','All the features available to a basic memebership to a user',to_date('03-25-2021','MM-DD-YYYY'),to_date('03-25-2021','MM-DD-YYYY'),to_date('03-26-2022','MM-DD-YYYY'));
insert into Feature values (1115, 'U-MLS–Standard-Feature','All the features available to a standard memebership to a user',to_date('03-25-2021','MM-DD-YYYY'),to_date('03-25-2021','MM-DD-YYYY'),to_date('03-26-2022','MM-DD-YYYY'));
insert into Feature values (1116, 'U-MLP–Premium-Feature','All the features available to a premium memebership to a user',to_date('03-25-2021','MM-DD-YYYY'),to_date('03-25-2021','MM-DD-YYYY'),to_date('03-26-2022','MM-DD-YYYY'));

create table Includes (
	membership_id INT,
	feature_id INT,
	FOREIGN KEY (membership_id) REFERENCES Membership(membership_id),
	FOREIGN KEY (feature_id) REFERENCES Feature(feature_id));

insert into Includes values (101, 1111);
insert into Includes values (102, 1112);
insert into Includes values (103, 1113);
insert into Includes values (104, 1114);
insert into Includes values (105, 1115);


create table Category ( 
	category_id INT, 
	category_name VARCHAR2(50), 
	description VARCHAR2(500), 
	parent_category INT,
	PRIMARY KEY (category_id));

insert into Category values (3001, 'Food', 'Any business related to Food industry including restaurants and coffee shops', 70);
insert into Category values (3002, 'Automotive', 'Any business related to Car Industry including car repair shops and dealerships', 75);
insert into Category values (3003, 'Finance', 'Any business that provides financial services such as Tax Attornerys, Accountants, Banks etc', 65);
insert into Category values (3004, 'Health & Beauty', 'Any business that provides health and beauty serivces including barbershops, spas, local beauty product companies etc.', 40);
insert into Category values (3005, 'Landscaping & Tree Services', 'Any business that provides land improvement, landscaping, tree trimming, new grass installaion services etc', 50);

create table Belong (
	business_id INT, 
	category_id INT, 
	FOREIGN KEY (business_id)REFERENCES Business(business_id),
	FOREIGN KEY (category_id)REFERENCES Category(category_id));

insert into Belong values (2001, 3001);
insert into Belong values (2002, 3003);
insert into Belong values (2003, 3001);
insert into Belong values (2004, 3002);
insert into Belong values (2005, 3005);

create table  Service_location ( 
	business_id INT, 
	city_name VARCHAR2(50), 
	county VARCHAR2(50), 
	state VARCHAR2(50), 
	zip_code VARCHAR2(50), 
	FOREIGN KEY (business_id) REFERENCES Business(business_id));

insert into Service_location values (2001, 'Round Rock','Williamson','TX','78756');
insert into Service_location values (2002, 'Round Rock','Williamson','TX','78717');
insert into Service_location values (2003, 'Round Rock','Williamson','TX','78681');
insert into Service_location values (2004, 'Cedar Park','Williamson', 'TX','78613');
insert into Service_location values (2005, 'Austin','Travis','TX','78703');

create table Address ( 
	address_id INT, 
	user_id INT,
	user_type VARCHAR2(10), 
	street VARCHAR2(50), 
	city VARCHAR2(50), 
	state VARCHAR2(2), 
	zip_code VARCHAR2(10), 
	primary_address_flag INT,
	PRIMARY KEY (address_id));

insert into Address values (5001, 1231, 'User', '106 S Mays St','Round Rock','TX','78664',1);
insert into Address values (5002, 1232, 'User', '15314 Oconto Dr.','Austin','TX','78717',1);
insert into Address values (5003, 1233, 'User', '4009 Isabella Ct.', 'Austin','TX','78702',1);
insert into Address values (5004, 1234, 'Business', '9411 Mays St.', 'Round Rock','TX','78664', 1);
insert into Address values (5005, 1235, 'Business', '666 Cat Hollow Dr.', 'Round Rock', 'TX','78661',1);
insert into Address values (5006, 1236, 'Business', '2403 S Bell Blvd', 'Cedar Park', 'TX','78613',1);

create table Job (
	job_id INT, 
	description VARCHAR2(500), 
	user_id INT,
	address_id INT, 
	business_id INT, 
	worked_by VARCHAR2(50), 
	job_status VARCHAR2(50), 
	creation_date DATE,  
	start_date DATE, 
	end_date DATE, 
	PRIMARY KEY (job_id),
	FOREIGN KEY (business_id) REFERENCES Business(business_id),
	FOREIGN KEY (address_id) REFERENCES Address(address_id),
	FOREIGN KEY (user_id) REFERENCES Users(user_id));

insert into Job values (7003, 'Looking for a Bartender', 1236, 5006, 2003, 'Jo Gaines','Active',to_date('03-25-2021','MM-DD-YYYY'),to_date('05-01-2021','MM-DD-YYYY'),to_date('05-01-2024','MM-DD-YYYY'));
insert into Job values (7004, 'Looking for a Barkback', 1236, 5006, 2003, 'Jason Roy','Active',to_date('03-25-2021','MM-DD-YYYY'),to_date('05-01-2021','MM-DD-YYYY'),to_date('05-01-2024','MM-DD-YYYY'));
insert into Job values (7005, 'Looking for a Tax Accountant', 1235, 5005, 2002, 'Xu Li','Active',to_date('03-25-2021','MM-DD-YYYY'),to_date('05-01-2021','MM-DD-YYYY'),to_date('05-01-2024','MM-DD-YYYY'));
insert into Job values (7006, 'Looking for a Senior Tax Accountant', 1235, 5005, 2002, 'Ken Wu','Active',to_date('03-25-2021','MM-DD-YYYY'),to_date('05-01-2021','MM-DD-YYYY'),to_date('05-01-2024','MM-DD-YYYY'));
insert into Job values (7007, 'Looking for a Lead Tax Accountant', 1235, 5005, 2002, 'Laura Mcaffrey','Active',to_date('03-25-2021','MM-DD-YYYY'),to_date('05-01-2021','MM-DD-YYYY'),to_date('05-01-2024','MM-DD-YYYY'));


create table Review (
	review_id INT, 
	user_id INT, 
	business_id INT, 
	rating_score DOUBLE PRECISION,
	review_text VARCHAR2(500),
	review_Images VARCHAR2(50), 
	creation_date DATE,
	last_updated_date DATE, 
	last_updated_by INT, 
	PRIMARY KEY (review_id),
	FOREIGN KEY (business_id) REFERENCES Business(business_id),
	FOREIGN KEY (user_id) REFERENCES Users(user_id));

insert into Review values (2101, 1231, 2001, 5.00, 'Amazing coffee, I had the irish cream iced latte and it was fantastic','coffeeimage.jpg',to_date('03-26-2021','MM-DD-YYYY'),to_date('03-27-2021','MM-DD-YYYY'),001);
insert into Review values (2102, 1231, 2003, 4.00, 'Service is slow, but the drinks are delicious','drinkimage.jpg',to_date('03-27-2021','MM-DD-YYYY'),to_date('03-28-2021','MM-DD-YYYY'),001);
insert into Review values (2103, 1232, 2001, 4.50, 'My partner loves this place, their coffee is good but bit expensive','coffeeimage2.jpg',to_date('03-27-2021','MM-DD-YYYY'),to_date('03-27-2021','MM-DD-YYYY'),001);
insert into Review values (2104, 1232, 2003, 5.00, 'Great drinks and wonderful staff','drinkimage2.jpg',to_date('03-27-2021','MM-DD-YYYY'),to_date('03-27-2021','MM-DD-YYYY'),001);
insert into Review values (2105, 1233, 2002, 1.00, 'Really poor experience, filed my tax return through them and they made numerous mistakes in my tax form','taxform.jpg',to_date('03-26-2021','MM-DD-YYYY'),to_date('03-27-2021','MM-DD-YYYY'),001);


create table Advertisement (
	ad_id INT, 
	business_id INT, 
	ad_content VARCHAR2(500), 
	template_name VARCHAR2(25), 
	creation_date DATE, 
	start_date DATE, 
	end_date DATE, 
	last_update_by INT,  
	PRIMARY KEY (ad_id),
	FOREIGN KEY (business_id) REFERENCES Business(business_id));

insert into Advertisement values (3031, 2001, 'Checkout our new lavender honey latte starting at $3.00','Banner',to_date('03-25-2021','MM-DD-YYYY'),to_date('03-26-2021','MM-DD-YYYY'),to_date('04-26-2021','MM-DD-YYYY'),001);
insert into Advertisement values (3032, 2002, 'File your taxes with us today and get the best returns !','Banner',to_date('03-25-2021','MM-DD-YYYY'),to_date('03-26-2021','MM-DD-YYYY'),to_date('04-26-2021','MM-DD-YYYY'),001);
insert into Advertisement values (3033, 2003, 'Happy Hour all day weekends for the month of April','Banner',to_date('03-25-2021','MM-DD-YYYY'),to_date('03-26-2021','MM-DD-YYYY'),to_date('04-26-2021','MM-DD-YYYY'),001);
insert into Advertisement values (3034, 2004, 'Free detailing for first 100 Users this weekend','Banner',to_date('03-25-2021','MM-DD-YYYY'),to_date('03-26-2021','MM-DD-YYYY'),to_date('04-26-2021','MM-DD-YYYY'),001);
insert into Advertisement values (3035, 2005, 'New limited price face masks starting at $1','Banner',to_date('03-25-2021','MM-DD-YYYY'),to_date('03-26-2021','MM-DD-YYYY'),to_date('04-26-2021','MM-DD-YYYY'),001);


create table Messages (
	message_id INT, 
	user_id INT,
	business_id INT, 
	message_text VARCHAR2(250), 
	message_date DATE,  
	PRIMARY KEY (message_id), 
	FOREIGN KEY (user_id) REFERENCES Users(user_id),
	FOREIGN KEY (business_id) REFERENCES Business(business_id));

insert into Messages values (7001, 1231, 2001, 'Are you guys open ?', to_date('03-25-2021','MM-DD-YYYY'));
insert into Messages values (7002, 1232, 2001, 'When will you start offering the lavender honey latte?', to_date('03-25-2021','MM-DD-YYYY'));
insert into Messages values (7003, 1233, 2001, 'Are dogs allowed ?', to_date('03-25-2021','MM-DD-YYYY'));
insert into Messages values (7004, 1231, 2005, 'Can i order online from your website ?', to_date('03-25-2021','MM-DD-YYYY'));
insert into Messages values (7005, 1232, 2003, 'Do you have any drink specials going on ?', to_date('03-25-2021','MM-DD-YYYY'));


create table  Clicks (
	user_id  INT, 
	business_id  INT, 
	creation_date DATE,  
	FOREIGN KEY (user_id) REFERENCES Users(user_id),
	FOREIGN KEY (business_id) REFERENCES Business(business_id));

insert into Clicks values (1231, 2001, to_date('03-25-2021','MM-DD-YYYY'));
insert into Clicks values (1232, 2001, to_date('03-25-2021','MM-DD-YYYY'));
insert into Clicks values (1233, 2001, to_date('03-25-2021','MM-DD-YYYY'));
insert into Clicks values (1231, 2005, to_date('03-25-2021','MM-DD-YYYY'));
insert into Clicks values (1232, 2003, to_date('03-25-2021','MM-DD-YYYY'));

create table Favorites (
	user_id INT, 
	business_id INT,
	FOREIGN KEY (user_id) REFERENCES Users(user_id),
	FOREIGN KEY (business_id) REFERENCES Business(business_id));

insert into Favorites values (1231, 2001);
insert into Favorites values (1232, 2001);
insert into Favorites values (1233, 2001);
insert into Favorites values (1231, 2005);
insert into Favorites values (1232, 2003);

create table  Preference (
	user_id INT,
	preference_label VARCHAR2(20), 
	preference_value VARCHAR2(5), 
	FOREIGN KEY (user_id) REFERENCES Users(user_id));

insert into Preference values (1231, 'coffee', 'Food');
insert into Preference values (1231, 'beer', 'Food');
insert into Preference values (1232, 'test', 'Food');
insert into Preference values (1232, 'cold brew', 'Food');
insert into Preference values (1233, 'latte', 'Food');

create table Payment_card_details (
	pay_id INT,
	user_id INT,
	card_name VARCHAR2(25), 
	card_number Number, 
	credit_card_type VARCHAR2(10),
	primary_flag INT,
	creation_date DATE, 
	last_updated_date DATE, 
	last_updated_by INT, 
	PRIMARY KEY (pay_id),
	FOREIGN KEY (user_id) REFERENCES Users(user_id));

insert into Payment_card_details values (811, 1234, 'Dave Bautista Credit Card','378084941472365', 'AMEX', 1, to_date('03-25-2021','MM-DD-YYYY'), to_date('05-25-2021','MM-DD-YYYY'), 001);
insert into Payment_card_details values (812, 1235, 'Racheal Zane Credit Card' ,'349114483435516', 'AMEX', 1, to_date('03-25-2021','MM-DD-YYYY'), to_date('05-25-2021','MM-DD-YYYY'), 001);
insert into Payment_card_details values (813, 1236, 'Lindsey Payne Credit Card', '370166871214566', 'AMEX', 1, to_date('03-25-2021','MM-DD-YYYY'), to_date('06-25-2021','MM-DD-YYYY'), 001);
insert into Payment_card_details values (814, 1231, 'Li Fang Credit Card' ,'4556003270644788', 'VISA', 1, to_date('03-25-2021','MM-DD-YYYY'), to_date('07-25-2021','MM-DD-YYYY'), 001);
insert into Payment_card_details values (815, 1232, 'Jay Cutler Credit Card','4532685489072261', 'VISA', 1, to_date('03-25-2021','MM-DD-YYYY'), to_date('08-25-2021','MM-DD-YYYY'), 001);


create table Pays_for (
	user_id INT, 
	pay_id INT,
	payment_for INT, 
	payment_label VARCHAR2(25), 
	amount DOUBLE PRECISION,
	payment_type VARCHAR2(50), 
	date_of_Payment DATE, 
	last_updated_date DATE,
	last_updated_by INT, 
	status VARCHAR2(50), 
	PRIMARY KEY (payment_for),
	FOREIGN KEY (user_id) REFERENCES Users(user_id),
	FOREIGN KEY (pay_id) REFERENCES Payment_card_details(pay_id));

insert into Pays_for values (1234, 811, 101, 'Membership', 99.00, 'Credit Card',to_date('03-24-2021','MM-DD-YYYY'), to_date('03-25-2021','MM-DD-YYYY'), 001, 'Active');
insert into Pays_for values (1235, 812, 102, 'Membership', 199.00, 'Credit Card', to_date('03-24-2021','MM-DD-YYYY'), to_date('03-25-2021','MM-DD-YYYY'), 001, 'Active');
insert into Pays_for values (1236, 813, 103, 'Membership', 349.00, 'Credit Card', to_date('03-24-2021','MM-DD-YYYY'), to_date('03-25-2021','MM-DD-YYYY'), 001, 'Active');
insert into Pays_for values (1231, 814, 105, 'Membership', 4.99, 'Credit Card', to_date('03-24-2021','MM-DD-YYYY'), to_date('03-25-2021','MM-DD-YYYY'), 001, 'Active');
insert into Pays_for values (1232, 815, 106, 'Membership', 9.99, 'Credit Card', to_date('03-24-2021','MM-DD-YYYY'), to_date('03-25-2021','MM-DD-YYYY'), 001, 'Active');


# Creating Review View 
CREATE VIEW user_reviews AS 
SELECT users.first_name, users.last_name, review.rating_score, review.review_text 
FROM users, review WHERE users.user_id = review.user_id AND users.user_id=1231;

#to format user_reviews table to look good 
#set linesize 500;
#column first_name format a10
#column last_name format a10
#column review_text format a20
#select * from user_reviews;



