-- Name - Jyotsna Shahi
-- Net_ID - j_s1294
--
--  Create a datbase for who does that application
--

set termout on
set feedback on
prompt Building sample who does that application database.  Please wait ...
set termout off
set feedback off

drop table Role cascade constraint;
drop table Super_user cascade constraint;
drop table Users cascade constraint;
drop table End_user cascade constraint;
drop table Business_user cascade constraint;
drop table Member cascade constraint;
drop table Membership cascade constraint;
drop table Feature cascade constraint;
drop table Includes cascade constraint;
drop table Business cascade constraint;
drop table Category cascade constraint;
drop table Belong cascade constraint;
drop table Service_location cascade constraint;
drop table Address cascade constraint;
drop table Job cascade constraint;
drop table Review cascade constraint;
drop table Advertisement cascade constraint;
drop table Messages cascade constraint;
drop table Clicks cascade constraint;
drop table Favorites cascade constraint;
drop table Preference cascade constraint;
drop table Payment_card_details cascade constraint;
drop table Pays_for cascade constraint;