Please read before running the script:

1. Install BeautifulSoup if you havent already 
pip3 install beautifulsoup4

2. We have already saved all the html files in a folder locally
In order to run the script please change the folder location on line 14.

3. To execute the script run the following command:

python3 mini_programming_jyotsna_shahi.py