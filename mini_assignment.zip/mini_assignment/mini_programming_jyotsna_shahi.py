# Name: Jyotsna Shahi, TxID: j_s1294

from bs4 import BeautifulSoup
import re
import glob
import pandas as pd
import numpy as np


# We saved all the file names in a list on which we will iterate over
all_files = (glob.glob("/Users/jyotsnashahi/Desktop/CS5338-Formal language/mini/*.html"))

# Initialize an empty dataframe that we will use later
df2 = pd.DataFrame()

# Loop through individual html files
for file in all_files:
	with open(file) as html_file:
		# We use beautifulsoup to read the html files, more info can be found here
		# https://www.crummy.com/software/BeautifulSoup/bs4/doc/
		soup = BeautifulSoup(html_file.read(), features='html.parser')
		# Names were found the in the current tag
		name = soup.find(class_='current')
		name_sanitized = name.get_text(strip=True)
		name_sanitized = name_sanitized.replace('\n','')
		first, last, *rest = name_sanitized.split()
		full_name = first+" "+last+" "
		# We saw in the html files that the majority details we wanted
		# were in the class tags panel-title and panel-body
		list_of_titles = soup.find_all(class_='panel-title')
		list_of_details = soup.findAll('div', attrs={'class': "panel-body"})
		get_titles = []
		get_details = []
		for title in list_of_titles:
			title_text = title.get_text(strip=True)
			get_titles.append(title_text)
		for detail in list_of_details:
			detail_text = detail.get_text(strip=True)
			get_details.append(detail_text)

		# We create a python dictionary using the two list, example:
		# {'Name': 'Rodion Podorozhny , 
		# 'Webpage': 'http://www.cs.txstate.edu/~rp3 ...}
		dictionary = dict(zip(get_titles, get_details))
		
		# Added the name to the dictionary
		dictionary['Name'] = full_name
		
		# Search for tags with text Homepage
		homepage = soup.find('a', text='Homepage')
		
		# Error handing in case no homepage is returned
		if homepage is not None:
			dictionary['Webpage'] = homepage['href']
		else:
			dictionary['Webpage'] = ''

		# We create pandas dataframe from the dictionary with dynamically created index
		df = pd.DataFrame(dictionary, index = np.arange(len(dictionary)))
		df2 = df2.append(df)

# Removed all the duplicate rows
df2 = df2.drop_duplicates()
# Filter out to only those columns that we care about
df2 = df2[['Name','Education','Research Interests','Office Location','Webpage']]
# Clean the column office location
df2['Office Location'] = df2['Office Location'].str.replace('San Marcos Campus','')

# Remove all Nans
df2 = df2.fillna('')

# Read each row of the dataframe and store it in seperate txt files
print("Creating new txt files ...")
for index, row in df2.iterrows():
	f = open(str(row['Name'])+'.txt', 'w')
	name_str = "Name: "+row['Name']
	edu_str = "Education: "+row['Education']
	res_str = "Research interests: "+row['Research Interests']
	loc_str = "Office location: " +row['Office Location']
	web_str = "Webpage: "+row['Webpage']
	f.write(name_str+'\n')
	f.write(edu_str+'\n')
	f.write(res_str+'\n')
	f.write(loc_str+'\n')
	f.write(web_str+'\n')
	f.close()

print("The script has finished running ...")