

// Using AWT container and component classes
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import model.State;
import model.KripkeStructure;
import controller.CTLFormula;
import model.Transition;
import utils.Util;


public class UI extends JFrame{

    private JTextField ctlFormula;
    private JLabel modelTitle;
    private JTextArea resultArea, modelText;
    private JComboBox<String> jComboBox;
    private JFrame jFrame;
    private BufferedReader orginalBI;
    private File filePath;

    private static KripkeStructure _kripke;


    public UI(){
        //constructor
        jFrame = new JFrame();
        jFrame.setTitle("CTL Model Checker");
        jFrame.setSize(new Dimension(500,500));
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        JPanel p1= (JPanel) getContentPane();
        p1.setLayout(new GridLayout(1,2));
        p1.setBorder(new EmptyBorder(10, 10, 10, 10));
        Border border = BorderFactory.createLineBorder(Color.ORANGE);
        p1.setBorder(border);

        JPanel mjPanel1 =  new JPanel();
        mjPanel1.setLayout(new GridLayout(7,1));
        mjPanel1.setBorder(new EmptyBorder(10, 10, 10, 10));


        jComboBox =  new JComboBox<String>();
        jComboBox.setSize(23,46);
        JPanel jPanel11 = new JPanel();
        jPanel11.setLayout(new GridLayout(2,2));
        jPanel11.add(new JLabel("Enter Model State : "));
        jPanel11.add(jComboBox);
        jPanel11.add(new JLabel("Enter CTL Formula: "));
        ctlFormula =  new JTextField(4);
        jPanel11.add(ctlFormula);
        jPanel11.setBorder(new EmptyBorder(1, 1, 2, 1));

        JPanel jPanel21 = new JPanel();
        jPanel21.setLayout(new GridLayout(1,2));

        JButton button1 = new JButton("Upload File");
        button1.addActionListener(new UploadFileListener());
        button1.setBackground(Color.orange);
        jPanel21.add(button1);

        JButton button = new JButton("Check");
        button.addActionListener(new UI.CheckActionListener());
        button.setBackground(Color.blue);
        button.setOpaque(true);
        jPanel21.add(button);
        jPanel21.setBorder(new EmptyBorder(1, 1, 2, 1));

        JPanel jPanel31 = new JPanel();
        jPanel31.setLayout(new GridLayout(1,1));
        jPanel31.add(new JLabel("Result: ",JLabel.CENTER));

        JPanel jPanel41 = new JPanel();
        jPanel41.setLayout(new GridLayout(1,1));

        resultArea = new JTextArea(10, 20);
        resultArea.setEditable(false);
        resultArea.setBorder(border);
        jPanel41.add(resultArea);
        jPanel41.setBorder(new EmptyBorder(5, 1, 1, 1));

        mjPanel1.add(jPanel11);
        mjPanel1.add(jPanel21);
        mjPanel1.add(jPanel31);
        mjPanel1.add(jPanel41);

        JPanel mjPanel2 =  new JPanel(new FlowLayout());
        mjPanel2.setBorder(new EmptyBorder(10, 10, 10, 10));
        modelTitle = new JLabel("Model");
        mjPanel2.add(modelTitle);

        JPanel jPanel22 = new JPanel();
        modelText = new JTextArea(22, 25);
        modelText.setEditable(false);
        jPanel22.add(modelText);
        modelText.setBorder(border);
        JScrollPane scrollPane = new JScrollPane(jPanel22);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setPreferredSize(new Dimension(500,500));

        mjPanel2.add(scrollPane);
        p1.add(mjPanel1);
        p1.add(mjPanel2);

        jFrame.setPreferredSize(new Dimension(800, 500));
        // jf.setJMenuBar(bar);
        jFrame.setContentPane(p1);
        jFrame.pack();
        jFrame.setVisible(true);
        jFrame.setLocationRelativeTo(null);

    }

    private void ClearModel() {
        modelText.setText("");
        modelTitle.setText("Model");
        if(jComboBox.getSelectedIndex() != -1) {
            DefaultComboBoxModel theModel = (DefaultComboBoxModel) jComboBox.getModel();
            theModel.removeAllElements();
        }
    }

    class UploadFileListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            ClearModel();
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setCurrentDirectory(new java.io.File("."));
            fileChooser.setFileFilter(new FileNameExtensionFilter("TEXT FILES", "txt", "text"));
            fileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
            int Value  = fileChooser.showOpenDialog(jFrame);
            if(Value == JFileChooser.APPROVE_OPTION) {
                try {
                    orginalBI = new BufferedReader(new FileReader(fileChooser.getSelectedFile()));
                    System.out.println("Selected File"+fileChooser.getSelectedFile());
                    filePath = fileChooser.getSelectedFile();

                    try {
                        if(filePath == null) {
                            String message  = "Please upload a File!";
                            JOptionPane.showMessageDialog(new JFrame(), message, "Comment",
                                    JOptionPane.ERROR_MESSAGE);
                        }
                        System.out.println("PATH: "+ filePath.getAbsolutePath());
                        String file = Util.readFile((filePath.getAbsolutePath()));
                        KripkeStructure kripke = new KripkeStructure(Util.cleanText(file));
                        _kripke = kripke;

                        if (_kripke == null)
                        {
                            Exception kf =  new Exception("Please upload Kripke model");
                            throw kf;
                        }else {
                            ClearModel();
                            for(String s: _kripke.getStates()) {
                                jComboBox.addItem(s);
                            }
                            String modelName = filePath.getAbsolutePath().substring(filePath.getAbsolutePath().lastIndexOf('M'));
                            modelTitle.setText(modelName);
                            modelText.setText(_kripke.toString());
                        }
                    }catch(Exception kse) {
                        kse.printStackTrace();
                        JOptionPane.showMessageDialog(new JFrame(), kse.getMessage(), "Dialog",
                                JOptionPane.ERROR_MESSAGE);
                    }
                }catch(IOException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(new JFrame(), ex.getMessage(), "Dialog",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    class CheckActionListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            resultArea.setText("");
            System.out.println("Clicked: " + e.getActionCommand()+" "+ctlFormula.getText());
            try {
                if (_kripke == null)
                {
                    Exception kf =  new Exception("Please load Kripke model");
                    throw kf;
                }
                if(ctlFormula.getText().isEmpty()) {
                    Exception cf =  new Exception("Please enter CTL formula!");
                    throw cf;
                }
                String originalExpression = ctlFormula.getText();
                String expression = originalExpression.replaceAll("\\s", "");
                System.out.println("Model.State  "+ jComboBox.getSelectedItem().toString());
                String checkedStateID = jComboBox.getSelectedItem().toString();

                State checkedState = new State(checkedStateID);

                controller.CTLFormula ctlFormula = new CTLFormula(expression, checkedState, _kripke);
                boolean isSatisfy = ctlFormula.IsSatisfy();
                String message = Util.GetMessage(isSatisfy, originalExpression, checkedStateID);
                resultArea.append(message);
                System.out.println(message);
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
                JOptionPane.showMessageDialog(new JFrame(), e1.getMessage(), "Dialog",
                        JOptionPane.ERROR_MESSAGE);
            }

        }
    }


}