package controller;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;

import model.KripkeStructure;
import model.State;
import view.View;

public class Controller {

    //private Model model;
    private View view;

    private String ctFile;
    private String stateId;
    private String ctlFormula;
    private KripkeStructure _kripke;

    public Controller()
    {

        view = new View(this);
    }

    public void setView(View v)
    {
        view = v;
    }
    public void setCtFile(String ct)
    {
        ctFile = ct;
    }
    public void setStateId(String id)
    {
        stateId = id;
    }
    public void setCtlFormula(String formula){
        ctlFormula = formula;
    }

    public static void main(String[] args) throws IOException {
        Controller control = new Controller();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the model number: ");
        String ctlFile = scanner.nextLine();
        if(ctlFile.matches("model(.*)"))
        {
            control.setCtFile(ctlFile);
        }
        else
        {
            System.out.println("Input format is not valid\n");
            System.exit(0);

        }
        System.out.println("Enter the state ID: ");
        String stateID = scanner.nextLine();
        if(stateID.matches("s[0-9]"))
        {
            control.setStateId(stateID);
        }
        else
        {
            System.out.println("Input format is not valid\n");
            System.exit(0);

        }

        System.out.println("Enter the CTL formula: ");
        String formula = scanner.nextLine();
        control.setCtlFormula(formula);

        Path fileNamePath = Path.of(ctlFile);
        String modelInputString = Files.readString(fileNamePath);
        KripkeStructure kripkeStructure = new KripkeStructure(modelInputString);

        State state = kripkeStructure.FindStateByName(stateID);
        CTLFormula ctlFormula = new CTLFormula(formula, state, kripkeStructure);
        boolean isSatisfy = ctlFormula.IsSatisfy();
        System.out.println("Lets test issatisfy");
        System.out.println(isSatisfy);

        if(isSatisfy) {
            System.out.println();
            System.out.println(String.format("Formula %s holds in state %s!", formula, stateID));
        } else {
            System.out.println();
            System.out.println(String.format("Formula %s does not hold in state %s! ", formula, stateID));
        }

        scanner.close();
    }
}
