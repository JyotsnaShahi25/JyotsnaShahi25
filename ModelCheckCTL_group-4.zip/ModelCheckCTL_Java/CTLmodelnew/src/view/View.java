package view;

import controller.Controller;

public class View {
    private Controller controller;

    public View(Controller c)
    {
        controller = c;
    }
}
