

create or replace view q1 as
	select distinct p.peid as PERSON#, p.firstname||' '||p.lastname as NAME from person p, buyer b, deal d
	where d.peid = b.peid and b.peid = p.peid
	order by p.peid
;

create or replace view q2 as
	select p.PNO, p.SUBURB, p.TYPE from property p, Property_for_Rent pr
	where p.pno = pr.pno
	intersect
	(select p.PNO, p.SUBURB, p.TYPE from property p, Property_for_Private_Sale ps
	where p.pno = ps.pno 
	union 
	select p.PNO, p.SUBURB, p.TYPE from property p, Property_for_Auction pa
	where p.pno = pa.pno)
;

create or replace view q3 as
	select o.peid as PERSON#, p.firstname||' '||p.lastname as NAME from person p, owner o, property pr
	where p.peid = o.peid and o.peid = pr.peid and lower(pr.type) = 'commercial' and lower(pr.suburb) = 'randwick'
	order by o.peid
;

create or replace view q4 as
	select count(p.peid) as NUMBER# from person p
	where peid not in (select peid from Contract)
	and peid not in (select peid from deal)
	and peid not in (select peid from owner)
;

create or replace view q5 as
	select sum(cpno) as NUMBER#, SUBURB from(
	select count(p.pno) as cpno, lower(p.suburb) as SUBURB from Property p, deal d
	where p.pno = d.pno
	having avg(d.price) < 500000
	group by SUBURB
	order by SUBURB)t
	group by SUBURB	
	order by 2
;

create or replace view q6 as
	select lower(p.suburb) as SUBURB, max(d.price) as MAXPRICE 
	from Property p, deal d, branch b
	where p.pno = d.pno and b.suburb = p.suburb
	group by p.suburb
	order by 1
;

create or replace view q7 as
	select lower(p.suburb) as SUBURB, count(p.pno) as NUMBER# 
	from Property p, Property_for_Rent pr
	where p.pno = pr.pno
	group by p.suburb
;

create or replace view q8 as
	select p.PNO, p.SUBURB, p.TYPE 
	from property p, advertisement a 
	where p.pno = a.pno
	having count(distinct(a.newspaper)) >=2
	group by p.PNO, p.SUBURB, p.TYPE 
;

create or replace view q9 as
	select * from (
	select peid, max(sumprice) as TOTAL from 
	(select p.peid, sum(d.price) as sumprice 
	from property p, deal d, contact c 
	where p.peid = c.peid and c.pno = d.pno 
	group by p.peid) t
	group by peid
	order by 2 desc) u
	where rownum = 1
;

create or replace view q10 as
	select b.peid, ps.pno, p.suburb, p.type
	from Property_for_Private_Sale ps,  buyer b, property p
	where  ps.pno = p.pno 
	and
	exists (select 1 from property p where ps.pno = p.pno and ps.asking_price <= b.max_price and lower(p.type) ='unit')
	and
	not exists ((select f.fid from required r, features f
	where b.peid = r.peid and f.fid = r.fid )
	minus
	(select f.fid from features f,  featured fd, property p
	where lower(p.type) ='unit' and f.fid = fd.fid and p.pno = fd.pno and p.pno = ps.pno ))
	order by b.peid 
;


create or replace
procedure topten(BranchNo integer)
as
	CURSOR agent_cursor IS 
    SELECT t1.peid, t1.count, t1.sum_price, p.firstname, p.lastname 
    FROM   person p, 
           (SELECT * 
            FROM   (SELECT t.peid AS peid, Count(1) AS count, SUM(d.price) AS sum_price 
                    FROM   deal d, (SELECT c.pno, c.peid FROM   contact c, staff s WHERE  s.peid = c.peid AND s.bno = BranchNo) t 
                    WHERE  d.pno = t.pno 
                    GROUP  BY t.peid 
                    ORDER  BY count DESC, sum_price DESC) 
            WHERE  ROWNUM <= 10) t1 
    WHERE  t1.peid = p.peid 
    ORDER  BY t1.count DESC, t1.sum_price DESC;    
BEGIN
  -- If you don't see the output printed on the console then run the below command before executing the procedure in sqlplus command line
  -- set serveroutput on size 30000;
  dbms_output.put_line('***************************');
  dbms_output.put_line('Top 10 staff');
  dbms_output.put_line('***************************');
  DBMS_OUTPUT.PUT_LINE('PEID' || '    ' || 'No sold' || '    ' || 'amount sold' || '    ' || 'NAME');

  FOR agent_record IN agent_cursor 
  LOOP
    DBMS_OUTPUT.PUT_LINE(agent_record.peid || '        ' || agent_record.count || '        ' || agent_record.sum_price || '        ' || agent_record.firstname || ' ' || agent_record.lastname);
  END LOOP;  

EXCEPTION
   WHEN OTHERS THEN
      dbms_output.put_line( SQLERRM );
end;
/

create or replace
procedure search(X IN Integer, FID1 IN Integer, FID2 IN Integer) 
is
   CURSOR prop_cursor IS 
   select p.suburb, p.pno from property p, deal d 
   where d.price < X and p.pno = d.pno and
   p.pno in (select pno from featured where fid = FID1 intersect select pno from featured where fid = FID2)
   order by p.pno desc;
   
BEGIN
  
  FOR precord IN prop_cursor 
  LOOP
	dbms_output.put_line('***************************');
    DBMS_OUTPUT.PUT_LINE(precord.suburb);
	dbms_output.put_line('***************************');
	dbms_output.put_line('Property ID');
	dbms_output.put_line('---');
	DBMS_OUTPUT.PUT_LINE(precord.pno);
  END LOOP;  

end;
/


create table Audits(
	PNO 	   INTEGER,
	USER_NAM   VARCHAR(20),
	DATE_CHAN  DATE,
	OLD_PRICE  REAL,
	NEW_PRICE  REAL
);

create or replace
trigger update_price_property 
	AFTER update ON Property_for_Private_Sale
	FOR EACH ROW
	when (old.pno = 80)
	BEGIN
	insert into Audits 
	values(:old.pno, user, sysdate, :old.asking_price, :new.asking_price );
END;
/
