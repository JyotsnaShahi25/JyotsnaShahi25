-- Cs5332 Project, Stage 3
-- ### Jyotsna Shahi ###

create or replace view q1 as
	select (p.givenname || ' '|| p.familyname) as name, 
	e.salary 
	from party p inner join employee e on p.id = e.id 
	where e.position = 'Underwriter';
;

create or replace view q2 as
	select (p.givenname || ' '|| p.familyname) as name, (p.street||','||' '||p.suburb||' '||p.state||' '||p.postcode) as address
	from party p 
	where p.id in ((select client from holds where policy in 
		(select policy from covers where coverage in
			(select coverage from RatingAction where action = 'D'))))
	order by name asc
;

create or replace view q3 as
	 select  (p.givenname || ' '|| p.familyname) as name from party p 
	 where p.id in (select h.client from holds h where h.policy in (select id from policy where status = 'OK'))
	 AND p.id in (select id from employee)
;


create or replace view q4 as
	select sum(premium) as MoneyCollected from policy;
;

create or replace view q5 as
	select sum(amount) as MoneyPaid from claimaction where action = 'PO';
;

create or replace view q6 as
	select (p.givenname || ' '|| p.familyname) as name
	from party p
	inner join holds h on p.id = h.client
	inner join claim c on h.policy = c.policy
	where h.client = c.claimant
;

create or replace view q7 as
	select c.policy  from covers c inner join coverage co on c.coverage = co.id
	inner join covereditem ci on c.item = ci.id
	where co.covervalue > ci.marketvalue
	group by c.policy
	order by c.policy asc;
;

create or replace view q8 as
	select ci.make, ci.model, count(*) as NumberInsured
	from covereditem ci
	group by ci.make, ci.model
	order by ci.make asc
;

-- Question 9 was solved using the concept of temporary tables
-- We first figured out all the employees and there policy 
-- and stored in a temporary table "emp_with_policy"
-- Then we selected all the employees who either rated or underwrote 
-- a policy held by an employee and stored that in a temporary table "emp_rater"
-- Then did an inner join on these two temporary tables to get the final result
create or replace view q9 as
	WITH emp_with_policy AS (
		select (p.givenname ||' '|| p.familyname) as name, h.policy 
		from party p inner join holds h on p.id = h.client 
		where h.client in (select id from employee)),
	emp_rater AS (
		select distinct(p.givenname || ' '|| p.familyname) as name,c.policy 
		from party p inner join ratingaction ra on p.id = ra.rater 
		inner join covers c on ra.coverage = c.coverage 
		where c.policy in (select policy from holds where holds.client in (select id from employee))
		UNION
		select distinct(p.givenname || ' '|| p.familyname) as name,ua.policy 
		from party p inner join underwritingaction ua on p.id = ua.underwriter 
		where ua.policy in (select policy from holds where holds.client in (select id from employee)))
	SELECT e.name as PolicyHolder, er.name as PolicyProcessor
	FROM emp_with_policy e inner join emp_rater er ON e.policy = er.policy
	order by e.name,er.name asc
;

-- In order to solve question 10, we have to figure out 
-- how many distinct types of coverages there were.

create or replace view q10 is
	select c.policy as id, ci.make, ci.model
	from covers c inner join covereditem ci on c.item = ci.id
	inner join coverage co on c.coverage = co.id
	group by c.policy, ci.make, ci.model
	having count(distinct(co.description)) = (select count(distinct(description)) from coverage);
;


CREATE or replace PROCEDURE discount
AS
	BEGIN
		UPDATE policy 
		SET premium = premium*0.9 
		WHERE policy.id in (select policy from holds where holds.client in (select id from employee));
	END;
/

create or replace procedure claims(policyID integer) 
is
	cursor policy_cursor is 
		select p.id , count(c.policy) as count from policy p left join claim c on p.id = c.policy where p.id = policyID group by p.id;
	cursor claim_cursor is
		select c.id,c.claimant,c.eventdate,c.reserve,
		CASE c.status WHEN 'A' THEN 'open' ELSE 'close' END AS status,
		cl.handler,cl.action,cl.happened,cl.actor,cl.amount
		from claim c inner join claimaction cl on c.id = cl.claim where c.policy = policyID order by id desc, happened asc;
BEGIN
	FOR policyrecord in policy_cursor
	LOOP
		DBMS_OUTPUT.PUT_LINE('Policy'|| policyID ||' '|| 'has' || ' ' || policyrecord.count || ' claims');
	END LOOP;
	FOR claimrecord IN claim_cursor
	<<outer_loop>>
	LOOP	
		DBMS_OUTPUT.PUT_LINE('---------------');
		DBMS_OUTPUT.PUT_LINE('Claim '|| claimrecord.id);
		DBMS_OUTPUT.PUT_LINE('Lodged by '|| claimrecord.claimant || ' on ' || claimrecord.eventdate);
		DBMS_OUTPUT.PUT_LINE('Event Date '|| claimrecord.eventdate);
		DBMS_OUTPUT.PUT_LINE('Reserve at:'||'      '||claimrecord.reserve);
		DBMS_OUTPUT.PUT_LINE('Status    :'||' '||claimrecord.status);
		DBMS_OUTPUT.PUT_LINE('Activity  :');
		<<inner_loop>>
		LOOP
			CASE 
				WHEN claimrecord.action = 'OP' THEN DBMS_OUTPUT.PUT_LINE('...'|| 'Claim opened by ' || claimrecord.handler ||'on '|| claimrecord.happened||' with reserve set to '||claimrecord.reserve);
				WHEN claimrecord.action = 'PO' THEN DBMS_OUTPUT.PUT_LINE('...'|| claimrecord.amount || ' paid out to ' || claimrecord.actor||' by '|| claimrecord.handler || ' on ' || claimrecord.happened);
				ELSE DBMS_OUTPUT.PUT_LINE('...Claim closed by'|| claimrecord.handler || ' on ' || claimrecord.happened);
			END CASE;
			EXIT inner_loop WHEN (j>)
		END LOOP inner_loop;
		DBMS_OUTPUT.PUT_LINE('---------------');
	END LOOP outer_loop;
EXCEPTION
	WHEN OTHERS THEN
		dbms_output.put_line("There is no policy: "||policyID);
	-- replace this line with your third PL/SQL procedure
end;
/


create or replace
procedure policy_rework_list 
is
	-- replace this line with your fourth PL/SQL procedure
end;
/
