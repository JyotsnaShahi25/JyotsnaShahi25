import pandas as pd

df = pd.read_csv('airport_data.csv')

print(df.head())