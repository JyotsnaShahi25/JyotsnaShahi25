from amadeus import Client, ResponseError
import pandas as pd

amadeus = Client(
    client_id='jJlvkmZTO3bM1rWaIRv5Ffsm8Ts8Mhpn',
    client_secret='W7uI6AprtEATum7f'
)

try:
    response = amadeus.shopping.flight_offers_search.get(
        originLocationCode='SYD',
        destinationLocationCode='BKK',
        departureDate='2020-12-01',
        adults=1)
    df = pd.DataFrame(response.data)
    print(df.head())
    df.to_csv('sample_data.csv',index=False)

except ResponseError as error:
    print(error)
