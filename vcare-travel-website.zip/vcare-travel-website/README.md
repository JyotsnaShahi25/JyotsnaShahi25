Web App to analyze PII data

# How to install and run this on your local machine

1. Clone the repository on your local machine or download it as a zip file
2. Do `cd sdcc-web-app`
3. Replace the values in .env.example with your values and rename this file to .env
3. Create a virtual environment and install all dependencies using the following
```
	python3 -m venv venv
	source venv/bin/activate
	pip install -r requirements.frozen
```
4. All done, now just run the command `flask run`
5. Now you can see the app on http://127.0.0.1:5000/