var checkout_public_key = 'pk_test_51HswaYBnskRh5vBvEsjOzZ4YKSw9Y9By2YOYGp6TTaO0Niq3UqZXeLgidLiQXqDYIg9XepacUyRrSvaufOPIdG7l00cNz5gklQ'

var stripe = Stripe()
const button = document.querySelector('#buy_now_btn');

button.addEventListener('click', event => {
    stripe.redirectToCheckout({
        // Make the id field from the Checkout Session creation API response
        // available to this file, so you can provide it as parameter here
        // instead of the {{CHECKOUT_SESSION_ID}} placeholder.
        sessionId: checkout_session_id
    }).then(function (result) {
        // If `redirectToCheckout` fails due to a browser or network
        // error, display the localized error message to your customer
        // using `result.error.message`.
    });
})
