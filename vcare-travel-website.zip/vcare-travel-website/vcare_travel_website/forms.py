"""Form class declaration."""
from flask_wtf import FlaskForm, RecaptchaField
from wtforms.validators import DataRequired


"""Form class declaration."""
from flask_wtf import FlaskForm, RecaptchaField
from wtforms import (
    DateField,
    PasswordField,
    SelectField,
    StringField,
    SubmitField,
    TextAreaField,
    IntegerField
)
from wtforms.validators import URL, DataRequired, Email, EqualTo, Length, ValidationError
from wtforms import validators


class ContactForm(FlaskForm):
    """Contact form."""

    name = StringField("Name", [DataRequired()])
    email = StringField(
        "Email", [Email(message="Not a valid email address."), DataRequired()]
    )
    body = TextAreaField(
        "Message", [DataRequired(), Length(min=4, message="Your message is too short.")]
    )
    submit = SubmitField("Submit")


class SignupForm(FlaskForm):
    """Sign up for a user account.""" 
    firstname = StringField("Fisrt Name *", [DataRequired()]) 
    middlename = StringField("Middle Name", [validators.optional()]) 
    lastname = StringField("Last Name *", [DataRequired()]) 
    mailingAddress = StringField("Mailing Address", [DataRequired()]) 
    email = StringField(
        "Email *", [Email(message="Not a valid email address."), DataRequired()]
    )
    password = PasswordField(
        "Password *",
        [
            DataRequired(message="Please enter a password."),
        ]
    )
    confirmPassword = PasswordField(
        "Repeat Password *", [EqualTo('password', message="Passwords must match.")]
    )
    # style={'stlye':'-webkit-appearance: menu !important;'}
    # ,render_kw=style
    CARD_TYPES = ('VISA','MASTER CARD','DISCOVER', 'AMERICAN EXPRESS')
    card_type = SelectField("Card Type *", [DataRequired()],choices=[(card_type, card_type) for card_type in CARD_TYPES]) 
    credit_card_number = IntegerField("Credit Card Number *", [DataRequired()]) 
    expiry_date = StringField("Expiry Date *", [DataRequired()]) 
    
    submit = SubmitField("Create Account")
    
    
class SignInForm(FlaskForm):
    """Sign up for a user account.""" 
    email = StringField(
        "Email", [Email(message="Not a valid email address."), DataRequired()]
    )
    password = PasswordField(
        "Password",
        [
            DataRequired(message="Please enter a password."),
        ],
    )
 
    submit = SubmitField("Login")
    def userNamePasswordValidator(self, result):
        if result == None:
            raise ValidationError("User Name or Password not matching")

class CheckStatus(FlaskForm):
    """Sign up for a user account.""" 
    carrier_code   = StringField("Carrier Code", [DataRequired()]) 
    flight_number  = IntegerField("Flight Number", [DataRequired()])
    departure_date = DateField("Departure Date",[DataRequired()])
 
    submit = SubmitField("Check Flight Status")