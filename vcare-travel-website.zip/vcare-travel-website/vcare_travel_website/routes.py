from flask import current_app as app
from flask import redirect, render_template, url_for, request, session
import pymysql
import pandas as pd
import numpy as np
from amadeus import Client, ResponseError
from sqlalchemy import create_engine
from commonregex import CommonRegex
import re
import time
import os
import datetime
from datetime import timedelta
import stripe
import itertools
import random

from .forms import ContactForm, SignupForm, SignInForm, CheckStatus
 
db = pymysql.connect(host='localhost',
    user='root',
    passwd='XORpunisher27',
    db='travel_website',
    autocommit=True
)

airport_data = pd.read_csv('airport_data.csv')
airline_data = pd.read_csv('airline_data.csv')

airline_data = airline_data.dropna()

# US only
airport_data = airport_data[airport_data['country']=='United States']

airport_data = airport_data[airport_data['airport_code']!="\\N"]
airport_data = airport_data[airport_data['airport_code'].notna()]


airport_list = airport_data['airport_code']

stripe_keys = {
	"publishable_key":"pk_test_51HswaYBnskRh5vBvEsjOzZ4YKSw9Y9By2YOYGp6TTaO0Niq3UqZXeLgidLiQXqDYIg9XepacUyRrSvaufOPIdG7l00cNz5gklQ",
	"secret_key":"sk_test_51HswaYBnskRh5vBv3WkCgWHifJ1jNCbdHMI22kUwBaoSn9EJQ2CdAXzBEeH7YK5aMEPd9mlw9n03ETUnsKp7WcOC00za4yTLNf"
}

stripe.api_key = stripe_keys["secret_key"]

def amadeus_api_call(origin_code,destination_code,departure_date,adults):
    amadeus = Client(
    client_id='jJlvkmZTO3bM1rWaIRv5Ffsm8Ts8Mhpn',
    client_secret='W7uI6AprtEATum7f'
    )
    try:
        response = amadeus.shopping.flight_offers_search.get(
            originLocationCode=origin_code,
            destinationLocationCode=destination_code,
            departureDate=departure_date,
            currencyCode='USD',
            adults=adults)
        api_data = pd.DataFrame(response.data)

    except ResponseError as error:
        print(error)

    api_data.to_csv('original_data.csv',index=False)
    itineraries = pd.concat([pd.DataFrame(x) for x in api_data['itineraries']], keys=api_data.index).reset_index(level=1, drop=True).reset_index()

    price = pd.concat([pd.DataFrame(x) for x in api_data['price']], keys=api_data.index).reset_index(level=1, drop=True).reset_index()

    price.insert(0, 'uid', range(100, 100 + len(price)))

    itineraries.insert(0, 'uid', range(100, 100 + len(itineraries)))

    formatted = itineraries.merge(price,on='uid',how='left')
    formatted['origin'] 	 	= origin_code
    formatted['destination'] 	= destination_code
    formatted['airline_code']	= api_data['validatingAirlineCodes']
    formatted['airline_code'] 	= formatted['airline_code'].astype(str)
    formatted['airline_code'] 	= formatted['airline_code'].str.replace("[","")
    formatted['airline_code'] 	= formatted['airline_code'].str.replace("]","")
    formatted['airline_code'] 	= formatted['airline_code'].str.replace("'","")

    formatted['duration'] 		= formatted['duration'].astype(str)
    formatted['duration']		= formatted['duration'].str.replace("PT","")

    final = formatted[['origin','destination','airline_code','duration','total']]
    final = final.merge(airline_data[['airline_code','airline_name']],on='airline_code',how='left')
    final = final[['origin','destination','airline_name','duration','total']]
    final.columns = ['Origin','Destination','Airline','Flight Duration','Total Price']
    return final.sample(n = 10) # Return random 10 results

@app.route("/index",methods=["GET", "POST"])
def index():
    return render_template("index.html")

@app.route("/",methods=["GET", "POST"])
def home():
    return render_template("index.html",airport_list = airport_list)

# Flight Search Results
@app.route("/flightsearch",methods=["GET","POST"])
def flightsearch():
    origin          = request.form.get('origin_code')
    destination     = request.form.get('destination_code')
    departure_date  = request.form.get('departure')
    adults          = 1
    formatted_date = datetime.datetime.strptime(departure_date, "%m/%d/%Y").strftime("%Y-%m-%d")
    dep_date = str(formatted_date)

    df = amadeus_api_call(origin,destination,dep_date,adults)
    results = df.to_dict('records')
    fieldnames = [key for key in results[0].keys()]
    return render_template('result.html', fieldnames=fieldnames,results=results,len=len)

# Flight Status Details
@app.route('/statusdetails',methods=["GET", "POST"])
def statusdetails():
    carrier_code          = request.form.get('carrier_code')
    flight_number         = request.form.get('flight_number')
    departure_date        = request.form.get('departure_date')
    
    status = ['In Flight','Arrived', 'Delayed']
    choice = random.choice(status)
    
    return render_template('statusdetails.html', 
        status=choice)

@app.route('/thanks')
def thanks():
    return render_template('thanks.html')

@app.route("/signin", methods=("GET", "POST"))
def signin():
    #Session time out
    session.permanent = True
    app.permanent_session_lifetime = timedelta(minutes=5)
    form = SignupForm()
    if form.validate_on_submit():
        return redirect(url_for("success"))
    return render_template("signin.html", form=form, template="form-template")


@app.route('/charge', methods=['GET', 'POST'])
def charge():
    if request.method == 'POST':
        data = {}
        data = request.json['itinerary']
        origin      = data['origin']
        destination = data['destination']
        airline     = data['airline']
        duration    = data['duration']
        price       = data['price']
        total_price = float(price)
        full_name   = 'John Doe'
        email       = 'johndoe@email.com'
        credit_card_number  = '4242424242424242'
        cc_expiration_date  = '2030-01-01'
        current_timestamp = datetime.datetime.today()
        cursor = db.cursor()
        cursor.execute(''' INSERT INTO book_flight (origin,destination,airline,duration,total_price,full_name,email,credit_card_number,cc_expiration_date,booking_date) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)''',(origin,destination,airline,duration,total_price,full_name,email,credit_card_number,cc_expiration_date,current_timestamp))
        cursor.close()
        print("Data Inserted Successfully !")
        url_for('checkout')
        return data

# Check Flight Status Form
@app.route('/checkstatus',methods=['GET', 'POST'])
def checkstatus():
    form = CheckStatus()
    return render_template("checkstatus.html", form=form, template="form-template")


@app.route('/checkout',methods=['POST'])
def checkout():
    cursor = db.cursor(pymysql.cursors.DictCursor)
    query = "SELECT * FROM book_flight ORDER BY booking_id DESC limit 1;"
    cursor.execute(query)
    dict1 = cursor.fetchall()
    print(dict1)
    newDict = {}
    for element in dict1:
        for k,v in element.items():
            newDict[k] = v
    required_fields = ['origin', 'destination', 'airline', 'duration','total_price']
    results = {key:value for key, value in newDict.items() if key in required_fields}
    print(results)
    session = stripe.checkout.Session.create(
		payment_method_types=['card'],
        line_items=[{
      		'price_data': {
        		'currency': 'usd',
        		'product_data': {
          			'name': 'Flight itinerary',
        		},
        		'unit_amount': int(results['total_price']*100),
      		},
      		'quantity': 1,
   		}]
   		, mode='payment',
        success_url=url_for('thanks', _external=True),
        cancel_url=url_for('charge', _external=True))

    description = "Origin: {} <br/> Destination: {}  <br/> Airline: {}  <br/> Duration: {} <br/> Total Price: {}".format(results['origin'],results['destination'],results['airline'],results['duration'],results['total_price'])
    
    return render_template('charge.html',checkout_session_id=session['id'], 
        checkout_public_key=stripe_keys['publishable_key'],
        description = description
        )