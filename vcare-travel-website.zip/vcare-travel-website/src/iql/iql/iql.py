#
# authors: Ivan Davtchev, Vladimir Markin
# last modified date: 2019-03-08 16:11 central time
#

import pandas as pd

import requests
import json
import re

import os, pwd

from future.standard_library import install_aliases
install_aliases()

from urllib.parse import urlencode

def describe(query_string, server='https://squall.indeed.com/iql2/', json=True, client='iql_py'):
    iql_server_url_query = server+ 'query'

    username = pwd.getpwuid(os.getuid())[0]

    if json:
        d = {'sync': 'sync', 'q': 'describe ' + query_string, 'username': username, 'client': client, 'json': True}
    else:
        d = {'sync': 'sync', 'q': 'describe ' + query_string, 'username': username, 'client': client}

    params = urlencode(d)
    full_url_query = iql_server_url_query + '?' + params

    if json:
        result = requests.get(full_url_query).json()
    else:
        result = pd.read_csv(full_url_query, sep='\t', quoting=3, header=None, names = ['name','description'])

    return result

def dataframe(query_string, server='https://squall.indeed.com/iql2/', header=True, clean=False, tuple=False, client='iql_py'):

    iql_server_url_query = server+ 'query'
    iql_server_url_split = server+ 'split'

    username = pwd.getpwuid(os.getuid())[0]

    d = {'sync': 'sync', 'q': query_string, 'username': username, 'client': client, 'v': 2, 'interactive': 1}
    params = urlencode(d)
    full_url_query = iql_server_url_query + '?' + params

    if header: # get the names of the fields and buckets to use as column names

        r = requests.get(iql_server_url_split, params=d)
        js = json.loads(r.text)

        func_args_pattern = r'\([^),]+,[^)]+\)'
        groupby_cleaned = re.sub(func_args_pattern, '', js['groupBy'])
        select_cleaned = re.sub(func_args_pattern, '', js['select'])

        column_names = []

        for groupby_part in groupby_cleaned.split(','):
            column_names.append(groupby_part.strip())

        for select_part in select_cleaned.split(','):
            column_names.append(select_part.strip())

        df = pd.read_csv(full_url_query, sep='\t', quoting=3, header=None, names=column_names)

    else: # dataframe without header (no fancy column names)

        df = pd.read_csv(full_url_query, sep='\t', quoting=3, header=None)

    if clean: # keep only beginning of the bucket
        df[df.columns[0]] = df[df.columns[0]].str.split(',').map(lambda x: x[0][1:])

    elif tuple: # split bucket to [begin,end] list
        df[df.columns[0]] = df[df.columns[0]].str[1:-1].map(lambda x: x.split(','))

    return df
