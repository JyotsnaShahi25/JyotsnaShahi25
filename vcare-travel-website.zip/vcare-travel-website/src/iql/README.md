# Deprecated
Use https://code.corp.indeed.com/python-libraries/iql-client instead.

# IQL-Python
A library for calling IQL from Python.  This library currently supports
python 2.7 and python3.6+.

## Install

### Install Local Environment
You can add `@tag` to version lock the version of the repository you pull in.
List of tags are available here: https://code.corp.indeed.com/imhotep/iql-python/tags

```
pip install git+https://code.corp.indeed.com/imhotep/iql-python.git
```

### Python Cron/Django Project (in requirements.frozen)
```
-e git+git@code.corp.indeed.com:imhotep/iql-python.git#egg=iql
```

## Examples

### New Supported Input
```
import iql
client = 'example'  # Replace with your LDAP or application's name
data = iql.dataframe('FROM jobsearch 2d 1d GROUP BY country SELECT count()',
                     client=client)
```

### Old Supported Input
```
from iql import iql
client = 'example'  # Replace with your LDAP or application's name
data = iql.dataframe('FROM jobsearch 2d 1d GROUP BY country SELECT count()',
                     client=client)
```
(Both import methods in Example 1 and Example 2 work.)

## Other Documentation
https://wiki.indeed.com/display/eng/2017/04/19/Install+IQL+in+Python+as+a+Pip+package
