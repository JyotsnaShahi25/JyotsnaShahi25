from distutils.core import setup

setup(
    name='iql',
    description='A library for calling IQL from Python',
    version='0.0.4',
    author='Ivan Davtchev, Vladimir Markin',
    packages=['iql'],
    install_requires=['requests', 'pandas', 'future'],
    url='https://wiki.indeed.com/display/PROD/Using+IQL+with+Python+and+Pandas'
)
